// ============================================================
// 🌿 RESINKRA - Resi Router (Roteador Central)
// Edge Function que gerencia o menu e roteia para os agentes
// ============================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { 
  RESI_AGENTS, 
  MENU_MESSAGE, 
  MENU_OPTIONS, 
  detectAgentFromMessage,
  API_CONFIG,
  ChatMessage,
  UserSession
} from "../_shared/resi-config.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Cache de sessões (em produção, usar Redis ou tabela no Supabase)
const sessions = new Map<string, UserSession>();

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { userId, message, platform = 'web' } = await req.json();

    if (!userId || !message) {
      return new Response(
        JSON.stringify({ error: 'userId e message são obrigatórios' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Inicializar Supabase
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Buscar ou criar sessão
    let session = sessions.get(userId);
    if (!session) {
      session = {
        userId,
        currentAgent: null,
        conversationHistory: [],
        lastActivity: new Date()
      };
      sessions.set(userId, session);
    }

    // Atualizar última atividade
    session.lastActivity = new Date();

    const trimmedMessage = message.trim();

    // ========================================
    // LÓGICA DE ROTEAMENTO
    // ========================================

    // 1. Verificar se usuário quer voltar ao menu
    if (trimmedMessage === '0' || trimmedMessage.toLowerCase() === 'menu' || trimmedMessage.toLowerCase() === 'voltar') {
      session.currentAgent = null;
      session.conversationHistory = [];
      
      return new Response(
        JSON.stringify({ 
          success: true,
          response: MENU_MESSAGE,
          currentAgent: null,
          showMenu: true
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 2. Se não tem agente selecionado, verificar opção do menu
    if (!session.currentAgent) {
      const selectedAgent = MENU_OPTIONS[trimmedMessage];
      
      if (selectedAgent) {
        // Usuário selecionou uma opção válida do menu
        session.currentAgent = selectedAgent;
        session.conversationHistory = [];
        
        const agent = RESI_AGENTS[selectedAgent];
        const welcomeMessage = `${agent.emoji} *${agent.name}* ao seu dispor!\n\n${agent.description}\n\nComo posso te ajudar? 💚\n\n_(Digite 0 a qualquer momento para voltar ao menu)_`;
        
        return new Response(
          JSON.stringify({ 
            success: true,
            response: welcomeMessage,
            currentAgent: selectedAgent,
            agentName: agent.name,
            showMenu: false
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      // Tentar detectar agente pela mensagem (fallback inteligente)
      const detectedAgent = detectAgentFromMessage(trimmedMessage);
      
      if (detectedAgent) {
        session.currentAgent = detectedAgent;
        // Continua para processar a mensagem com o agente detectado
      } else {
        // Não detectou, mostrar menu novamente
        return new Response(
          JSON.stringify({ 
            success: true,
            response: `Não entendi sua escolha. 🤔\n\n${MENU_MESSAGE}`,
            currentAgent: null,
            showMenu: true
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // ========================================
    // PROCESSAR MENSAGEM COM O AGENTE
    // ========================================

    const currentAgent = RESI_AGENTS[session.currentAgent!];
    
    // Adicionar mensagem do usuário ao histórico
    session.conversationHistory.push({
      role: 'user',
      content: trimmedMessage
    });

    // Buscar contexto do usuário no banco (opcional mas recomendado)
    let userContext = '';
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('nome, tier, cashback_saldo')
        .eq('id', userId)
        .single();

      if (profile) {
        userContext = `\n\n[CONTEXTO DO USUÁRIO]
- Nome: ${profile.nome || 'Não informado'}
- Tier: ${profile.tier || 'Bronze'}
- Saldo Cashback: R$ ${profile.cashback_saldo || 0}`;
      }
    } catch (e) {
      // Ignora erro se não conseguir buscar contexto
      console.log('Contexto do usuário não disponível');
    }

    // Montar mensagens para a API
    const messages: ChatMessage[] = [
      {
        role: 'system',
        content: currentAgent.systemPrompt + userContext
      },
      ...session.conversationHistory.slice(-10) // Últimas 10 mensagens para contexto
    ];

    // Chamar API da Lovable AI
    const aiResponse = await fetch(API_CONFIG.lovableApiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_CONFIG.lovableApiKey}`
      },
      body: JSON.stringify({
        model: API_CONFIG.model,
        messages: messages,
        max_tokens: API_CONFIG.maxTokens,
        temperature: API_CONFIG.temperature
      })
    });

    if (!aiResponse.ok) {
      throw new Error(`Erro na API: ${aiResponse.status}`);
    }

    const aiData = await aiResponse.json();
    const assistantMessage = aiData.choices[0]?.message?.content || 
      'Desculpe, tive um problema ao processar sua mensagem. Pode tentar novamente?';

    // Adicionar resposta ao histórico
    session.conversationHistory.push({
      role: 'assistant',
      content: assistantMessage
    });

    // Salvar interação no banco (para analytics)
    try {
      await supabase.from('chat_interactions').insert({
        user_id: userId,
        agent: session.currentAgent,
        user_message: trimmedMessage,
        assistant_message: assistantMessage,
        platform: platform,
        created_at: new Date().toISOString()
      });
    } catch (e) {
      console.log('Erro ao salvar interação:', e);
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        response: assistantMessage,
        currentAgent: session.currentAgent,
        agentName: currentAgent.name,
        agentEmoji: currentAgent.emoji,
        showMenu: false
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Erro no resi-router:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false,
        error: 'Erro interno do servidor',
        response: '😔 Ops! Tive um probleminha técnico. Pode tentar novamente em alguns segundos?'
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
