// ============================================================
// 🌿 RESINKRA - Resi WhatsApp Webhook
// Edge Function para integração com WhatsApp via Z-API
// ============================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { MENU_MESSAGE } from "../_shared/resi-config.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Configuração Z-API
const ZAPI_INSTANCE_ID = Deno.env.get('ZAPI_INSTANCE_ID')!;
const ZAPI_TOKEN = Deno.env.get('ZAPI_TOKEN')!;
const ZAPI_BASE_URL = `https://api.z-api.io/instances/${ZAPI_INSTANCE_ID}/token/${ZAPI_TOKEN}`;

// Função para enviar mensagem via Z-API
async function sendWhatsAppMessage(phone: string, message: string) {
  const response = await fetch(`${ZAPI_BASE_URL}/send-text`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      phone: phone,
      message: message
    })
  });

  return response.json();
}

// Função para enviar mensagem com botões (lista)
async function sendWhatsAppList(phone: string) {
  const response = await fetch(`${ZAPI_BASE_URL}/send-button-list`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      phone: phone,
      message: "🌿 Olá! Sou a Resi, sua assistente da Resinkra!",
      buttonList: {
        title: "Como posso ajudar?",
        buttons: [
          { id: "1", title: "💬 Dúvidas Gerais" },
          { id: "2", title: "📅 Agendamentos" },
          { id: "3", title: "🎬 Criar Conteúdo" },
          { id: "4", title: "🛒 Produtos/Pacotes" },
          { id: "5", title: "🧘 Bem-estar" }
        ]
      }
    })
  });

  return response.json();
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const payload = await req.json();
    
    // Log para debug
    console.log('WhatsApp Webhook recebido:', JSON.stringify(payload));

    // Verificar se é uma mensagem recebida
    if (!payload.isFromMe && payload.type === 'ReceivedCallback') {
      const phone = payload.phone;
      const message = payload.text?.message || payload.listResponseMessage?.title || '';
      const buttonId = payload.listResponseMessage?.selectedButtonId || null;

      if (!phone || !message) {
        return new Response(JSON.stringify({ status: 'ignored' }), { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        });
      }

      // Inicializar Supabase
      const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
      const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
      const supabase = createClient(supabaseUrl, supabaseKey);

      // Buscar usuário pelo telefone
      let userId = null;
      try {
        const { data: profile } = await supabase
          .from('profiles')
          .select('id')
          .eq('telefone', phone)
          .single();
        
        userId = profile?.id;
      } catch (e) {
        console.log('Usuário não encontrado pelo telefone');
      }

      // Se não encontrou usuário, criar um ID temporário baseado no telefone
      if (!userId) {
        userId = `whatsapp_${phone}`;
      }

      // Determinar a mensagem a processar
      let messageToProcess = buttonId || message;

      // Chamar o resi-router para processar
      const routerResponse = await fetch(`${Deno.env.get('SUPABASE_URL')}/functions/v1/resi-router`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${Deno.env.get('SUPABASE_ANON_KEY')}`
        },
        body: JSON.stringify({
          userId: userId,
          message: messageToProcess,
          platform: 'whatsapp'
        })
      });

      const routerData = await routerResponse.json();

      // Enviar resposta via WhatsApp
      if (routerData.showMenu) {
        // Se é para mostrar menu, tentar enviar lista de botões
        try {
          await sendWhatsAppList(phone);
        } catch (e) {
          // Fallback para texto simples se botões não funcionarem
          await sendWhatsAppMessage(phone, routerData.response);
        }
      } else {
        // Resposta normal em texto
        let responseMessage = routerData.response;
        
        // Adicionar indicador do agente atual
        if (routerData.agentEmoji && routerData.agentName) {
          responseMessage = `${routerData.agentEmoji} *${routerData.agentName}*\n\n${responseMessage}`;
        }
        
        await sendWhatsAppMessage(phone, responseMessage);
      }

      // Salvar log da interação
      try {
        await supabase.from('whatsapp_logs').insert({
          phone: phone,
          user_id: userId,
          message_received: messageToProcess,
          message_sent: routerData.response,
          agent: routerData.currentAgent,
          created_at: new Date().toISOString()
        });
      } catch (e) {
        console.log('Erro ao salvar log WhatsApp:', e);
      }

      return new Response(
        JSON.stringify({ status: 'processed', agent: routerData.currentAgent }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Outros tipos de callback (status, etc)
    return new Response(
      JSON.stringify({ status: 'acknowledged' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Erro no webhook WhatsApp:', error);
    
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
