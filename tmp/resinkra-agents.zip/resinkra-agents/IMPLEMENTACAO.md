# ============================================================
# 🌿 RESINKRA - Guia de Implementação dos Agentes Resi
# ============================================================

## 📦 Arquivos Criados

```
resinkra-agents/
├── supabase/
│   ├── functions/
│   │   ├── _shared/
│   │   │   └── resi-config.ts        # Configurações e prompts dos agentes
│   │   ├── resi-router/
│   │   │   └── index.ts              # Roteador central (menu + IA)
│   │   └── resi-whatsapp/
│   │       └── index.ts              # Webhook para WhatsApp (Z-API)
│   └── migrations/
│       └── 20240219_resi_chat_tables.sql  # Tabelas do banco
└── src/
    └── components/
        └── chat/
            └── ResiChat.tsx          # Componente React do chat
```

---

## 🚀 Passo a Passo de Implementação

### 1️⃣ Configurar Variáveis de Ambiente

Adicione no seu Supabase (Settings > Edge Functions > Secrets):

```env
# Lovable AI / OpenAI
LOVABLE_API_URL=https://api.lovable.ai/v1/chat/completions
LOVABLE_API_KEY=sua_chave_aqui

# Z-API (WhatsApp)
ZAPI_INSTANCE_ID=seu_instance_id
ZAPI_TOKEN=seu_token

# Supabase (já deve estar configurado)
SUPABASE_URL=https://seu-projeto.supabase.co
SUPABASE_ANON_KEY=sua_anon_key
SUPABASE_SERVICE_ROLE_KEY=sua_service_role_key
```

---

### 2️⃣ Rodar a Migration SQL

Execute o arquivo `20240219_resi_chat_tables.sql` no SQL Editor do Supabase.

Isso criará:
- `chat_interactions` - Histórico de todas as conversas
- `chat_sessions` - Sessões ativas dos usuários
- `whatsapp_logs` - Logs de mensagens WhatsApp
- `resi_agents_config` - Configuração dos agentes (ativar/desativar)

---

### 3️⃣ Fazer Deploy das Edge Functions

No terminal do seu projeto:

```bash
# Copiar arquivos para seu projeto
cp -r resinkra-agents/supabase/functions/* seu-projeto/supabase/functions/

# Deploy das funções
supabase functions deploy resi-router
supabase functions deploy resi-whatsapp
```

---

### 4️⃣ Adicionar Componente React

Copie o arquivo `ResiChat.tsx` para `src/components/chat/` do seu projeto.

No seu `App.tsx` ou layout principal, adicione:

```tsx
import { ResiChat } from '@/components/chat/ResiChat';

function App() {
  return (
    <>
      {/* Seu app existente */}
      <ResiChat />
    </>
  );
}
```

---

### 5️⃣ Configurar Webhook no Z-API

No painel do Z-API:
1. Vá em Configurações > Webhooks
2. Configure a URL: `https://seu-projeto.supabase.co/functions/v1/resi-whatsapp`
3. Ative os eventos de mensagem recebida

---

## 🎛️ Como Ativar/Desativar Agentes

### Via SQL (Supabase Dashboard)

```sql
-- Desativar Resi Loja
UPDATE resi_agents_config 
SET is_active = false 
WHERE id = 'loja';

-- Reativar Resi Loja
UPDATE resi_agents_config 
SET is_active = true 
WHERE id = 'loja';

-- Ver status de todos os agentes
SELECT id, name, emoji, is_active FROM resi_agents_config;
```

### Via Painel Admin (criar depois)

Você pode criar uma aba no painel admin para gerenciar os agentes com toggles visuais.

---

## 📊 Ver Analytics das Conversas

```sql
-- Estatísticas dos últimos 7 dias
SELECT * FROM get_resi_stats(7);

-- Conversas por dia e agente
SELECT * FROM chat_analytics 
WHERE date > NOW() - INTERVAL '7 days';

-- Top usuários
SELECT user_id, COUNT(*) as mensagens
FROM chat_interactions
WHERE created_at > NOW() - INTERVAL '7 days'
GROUP BY user_id
ORDER BY mensagens DESC
LIMIT 10;
```

---

## 🔄 Fluxo de Funcionamento

```
┌─────────────────────────────────────────────────────────────────┐
│                        USUÁRIO                                  │
│                   (Web ou WhatsApp)                             │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                 RESI-ROUTER (Edge Function)                     │
│                                                                 │
│  1. Recebe mensagem                                             │
│  2. Verifica se usuário tem sessão ativa                        │
│  3. Se não tem agente → Mostra menu                             │
│  4. Se tem agente → Processa com IA                             │
│  5. Salva interação no banco                                    │
│  6. Retorna resposta                                            │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                    LOVABLE AI (GPT/Gemini)                      │
│                                                                 │
│  • Recebe system prompt do agente selecionado                   │
│  • Recebe contexto do usuário (nome, tier, saldo)               │
│  • Recebe histórico da conversa                                 │
│  • Gera resposta personalizada                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🛠️ Customizações Possíveis

### Adicionar Novo Agente

Em `resi-config.ts`, adicione no objeto `RESI_AGENTS`:

```typescript
novoAgente: {
  id: 'novo-agente',
  name: 'Resi Novo',
  emoji: '🆕',
  description: 'Descrição do novo agente',
  keywords: ['palavra1', 'palavra2'],
  systemPrompt: `Você é a Resi Novo...`
}
```

### Alterar Modelo de IA

Em `resi-config.ts`, altere `API_CONFIG`:

```typescript
export const API_CONFIG = {
  // Para GPT-4
  model: 'gpt-4o',
  
  // Para Gemini
  // lovableApiUrl: 'https://api.google.com/...',
  // model: 'gemini-pro',
};
```

### Adicionar Contexto Específico

No `resi-router/index.ts`, expanda a busca de contexto:

```typescript
// Buscar agendamentos pendentes
const { data: agendamentos } = await supabase
  .from('agendamentos')
  .select('*')
  .eq('user_id', userId)
  .eq('status', 'pendente');

userContext += `\n- Agendamentos pendentes: ${agendamentos?.length || 0}`;
```

---

## ⚠️ Notas Importantes

1. **Rate Limiting**: Considere implementar limite de mensagens por usuário
2. **Custos**: Monitore o uso de tokens da API de IA
3. **Backup**: As conversas ficam salvas em `chat_interactions`
4. **LGPD**: Implemente política de retenção de dados conforme necessário

---

## 📞 Suporte

Se precisar de ajuda com a implementação, é só me chamar!

🌿 **Resinkra - Bem-estar e Tecnologia**
