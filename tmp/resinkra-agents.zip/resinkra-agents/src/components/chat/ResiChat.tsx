// ============================================================
// 🌿 RESINKRA - Componente React do Chat Resi
// Interface de chat para integração no frontend
// ============================================================

import React, { useState, useRef, useEffect } from 'react';
import { Send, X, MessageCircle, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { motion, AnimatePresence } from 'framer-motion';

interface Message {
  id: string;
  role: 'user' | 'assistant' | 'menu';
  content: string;
  agentName?: string;
  agentEmoji?: string;
  timestamp: Date;
}

interface MenuOption {
  id: string;
  emoji: string;
  title: string;
  description: string;
}

const MENU_OPTIONS: MenuOption[] = [
  { id: '1', emoji: '💬', title: 'Dúvidas Gerais', description: 'Cashback, indicações, plataforma' },
  { id: '2', emoji: '📅', title: 'Agendamentos', description: 'Marcar, remarcar ou cancelar sessões' },
  { id: '3', emoji: '🎬', title: 'Criar Conteúdo', description: 'Roteiros e ideias para redes sociais' },
  { id: '4', emoji: '🛒', title: 'Produtos e Pacotes', description: 'Comprar óleos, pacotes de sessões' },
  { id: '5', emoji: '🧘', title: 'Bem-estar', description: 'Dicas de saúde e relaxamento' },
];

export function ResiChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentAgent, setCurrentAgent] = useState<string | null>(null);
  const [showMenu, setShowMenu] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();

  // Auto-scroll para última mensagem
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  // Mensagem inicial ao abrir
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([{
        id: 'welcome',
        role: 'assistant',
        content: '🌿 Olá! Sou a Resi, sua assistente da Resinkra!\n\nComo posso te ajudar hoje?',
        timestamp: new Date()
      }]);
      setShowMenu(true);
    }
  }, [isOpen]);

  // Função para enviar mensagem
  const sendMessage = async (messageText: string) => {
    if (!messageText.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: messageText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);
    setShowMenu(false);

    try {
      const { data, error } = await supabase.functions.invoke('resi-router', {
        body: {
          userId: user?.id || 'anonymous',
          message: messageText,
          platform: 'web'
        }
      });

      if (error) throw error;

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.response,
        agentName: data.agentName,
        agentEmoji: data.agentEmoji,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
      setCurrentAgent(data.currentAgent);
      setShowMenu(data.showMenu);

    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: '😔 Ops! Tive um probleminha. Pode tentar novamente?',
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  // Função para selecionar opção do menu
  const selectMenuOption = (optionId: string) => {
    sendMessage(optionId);
  };

  // Função para voltar ao menu
  const backToMenu = () => {
    sendMessage('0');
  };

  // Renderizar mensagem
  const renderMessage = (message: Message) => {
    const isUser = message.role === 'user';

    return (
      <motion.div
        key={message.id}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-3`}
      >
        <div
          className={`max-w-[85%] rounded-2xl px-4 py-2.5 ${
            isUser
              ? 'bg-green-600 text-white rounded-br-md'
              : 'bg-gray-100 text-gray-800 rounded-bl-md'
          }`}
        >
          {!isUser && message.agentName && (
            <div className="text-xs font-medium text-green-700 mb-1">
              {message.agentEmoji} {message.agentName}
            </div>
          )}
          <p className="text-sm whitespace-pre-wrap">{message.content}</p>
          <span className={`text-[10px] ${isUser ? 'text-green-200' : 'text-gray-400'} mt-1 block`}>
            {message.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </motion.div>
    );
  };

  // Renderizar menu de opções
  const renderMenu = () => (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="grid grid-cols-1 gap-2 p-2"
    >
      {MENU_OPTIONS.map((option) => (
        <button
          key={option.id}
          onClick={() => selectMenuOption(option.id)}
          className="flex items-center gap-3 p-3 bg-white border border-gray-200 rounded-xl hover:bg-green-50 hover:border-green-300 transition-all text-left group"
        >
          <span className="text-2xl">{option.emoji}</span>
          <div>
            <div className="font-medium text-gray-800 group-hover:text-green-700">
              {option.title}
            </div>
            <div className="text-xs text-gray-500">
              {option.description}
            </div>
          </div>
        </button>
      ))}
    </motion.div>
  );

  return (
    <>
      {/* Botão flutuante */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-br from-green-500 to-green-600 rounded-full shadow-lg flex items-center justify-center text-white z-50 hover:shadow-xl transition-shadow"
          >
            <MessageCircle size={24} />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed bottom-6 right-6 w-[380px] h-[600px] bg-white rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden border border-gray-200"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-green-500 to-green-600 p-4 flex items-center justify-between text-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                  🌿
                </div>
                <div>
                  <h3 className="font-semibold">Resi</h3>
                  <p className="text-xs text-green-100">
                    {currentAgent ? `${MENU_OPTIONS.find(o => o.id === currentAgent.toString())?.title || 'Online'}` : 'Online'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {currentAgent && (
                  <button
                    onClick={backToMenu}
                    className="text-xs bg-white/20 hover:bg-white/30 px-3 py-1.5 rounded-full transition-colors"
                  >
                    Menu
                  </button>
                )}
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 hover:bg-white/20 rounded-full transition-colors"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 p-4" ref={scrollRef}>
              {messages.map(renderMessage)}
              
              {/* Menu de opções */}
              {showMenu && !isLoading && renderMenu()}

              {/* Loading */}
              {isLoading && (
                <div className="flex justify-start mb-3">
                  <div className="bg-gray-100 rounded-2xl rounded-bl-md px-4 py-3">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  </div>
                </div>
              )}
            </ScrollArea>

            {/* Input */}
            <div className="p-4 border-t border-gray-100 bg-gray-50">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  sendMessage(inputValue);
                }}
                className="flex gap-2"
              >
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Digite sua mensagem..."
                  className="flex-1 rounded-full border-gray-200 focus:border-green-400 focus:ring-green-400"
                  disabled={isLoading}
                />
                <Button
                  type="submit"
                  size="icon"
                  disabled={isLoading || !inputValue.trim()}
                  className="rounded-full bg-green-500 hover:bg-green-600 w-10 h-10"
                >
                  <Send size={18} />
                </Button>
              </form>
              <p className="text-[10px] text-gray-400 text-center mt-2">
                Resinkra AI • Digite 0 para voltar ao menu
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

export default ResiChat;
