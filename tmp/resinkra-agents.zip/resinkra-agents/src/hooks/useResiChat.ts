// ============================================================
// 🌿 RESINKRA - Hook useResiChat
// Hook React para usar o chat em qualquer componente
// ============================================================

import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  agentName?: string;
  agentEmoji?: string;
  timestamp: Date;
}

interface UseResiChatReturn {
  messages: Message[];
  isLoading: boolean;
  currentAgent: string | null;
  showMenu: boolean;
  sendMessage: (message: string) => Promise<void>;
  selectAgent: (agentId: string) => Promise<void>;
  backToMenu: () => Promise<void>;
  clearChat: () => void;
}

export function useResiChat(): UseResiChatReturn {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentAgent, setCurrentAgent] = useState<string | null>(null);
  const [showMenu, setShowMenu] = useState(true);
  const { user } = useAuth();

  const sendMessage = useCallback(async (messageText: string) => {
    if (!messageText.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: messageText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);
    setShowMenu(false);

    try {
      const { data, error } = await supabase.functions.invoke('resi-router', {
        body: {
          userId: user?.id || 'anonymous',
          message: messageText,
          platform: 'web'
        }
      });

      if (error) throw error;

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.response,
        agentName: data.agentName,
        agentEmoji: data.agentEmoji,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
      setCurrentAgent(data.currentAgent);
      setShowMenu(data.showMenu);

    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: '😔 Ops! Tive um probleminha. Pode tentar novamente?',
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  }, [isLoading, user?.id]);

  const selectAgent = useCallback(async (agentId: string) => {
    await sendMessage(agentId);
  }, [sendMessage]);

  const backToMenu = useCallback(async () => {
    await sendMessage('0');
  }, [sendMessage]);

  const clearChat = useCallback(() => {
    setMessages([]);
    setCurrentAgent(null);
    setShowMenu(true);
  }, []);

  return {
    messages,
    isLoading,
    currentAgent,
    showMenu,
    sendMessage,
    selectAgent,
    backToMenu,
    clearChat
  };
}

export default useResiChat;
